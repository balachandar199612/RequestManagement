using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RequestManagement.Data;
using RequestManagement.Models;
using System.ComponentModel.DataAnnotations;

namespace RequestManagement.Controllers
{

        [Route("api/[controller]")]
        [ApiController]
        public class LeaveRequestController : ControllerBase
        {
            private readonly AppDBContext _context;

            public LeaveRequestController(AppDBContext context)
            {
                _context = context;
            }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> CreateLeaveRequest([FromBody] LeaveRequest dto)
        {
            if (dto.FromDate < DateTime.Today)
                return BadRequest("Leave start date cannot be in the past.");

            var employeeId = GetAuthenticatedEmployeeId();
            var employeeExists = await _context.Employees.AnyAsync(e => e.Id == employeeId);
            if (!employeeExists)
                return BadRequest("Employee not found.");

            var leaveRequest = new LeaveRequest
            {
                EmployeeId = employeeId,
                FromDate = dto.FromDate,
                ToDate = dto.ToDate,
                Reason = dto.Reason,
                Status = dto.Status
            };

            _context.LeaveRequests.Add(leaveRequest);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetLeaveRequest", new { id = leaveRequest.Id }, leaveRequest);
        }


        [HttpGet]
            [Authorize]
            public async Task<IActionResult> GetLeaveRequests()
            {
                var employeeId = GetAuthenticatedEmployeeId();

                if (User.IsInRole("Admin"))
                {
                    var leaveRequests = await _context.LeaveRequests.ToListAsync();
                    return Ok(leaveRequests);
                }

                var employeeLeaveRequests = await _context.LeaveRequests
                    .Where(lr => lr.EmployeeId == employeeId)
                    .ToListAsync();

                return Ok(employeeLeaveRequests);
            }

            [HttpGet("{id}")]
            [Authorize]
            public async Task<IActionResult> GetLeaveRequest(int id)
            {
                var leaveRequest = await _context.LeaveRequests.FindAsync(id);

                if (leaveRequest == null)
                    return NotFound();

                var employeeId = GetAuthenticatedEmployeeId();
                if (leaveRequest.EmployeeId != employeeId && !User.IsInRole("Admin"))
                    return Unauthorized();

                return Ok(leaveRequest);
            }

            [HttpPut("{id}")]
            [Authorize(Roles = "Admin")]
            public async Task<IActionResult> UpdateLeaveRequest(int id, [FromBody] LeaveRequest updatedLeaveRequest)
            {
                if (updatedLeaveRequest == null || updatedLeaveRequest.Id != id)
                    return BadRequest("Leave request data is invalid.");

                var leaveRequest = await _context.LeaveRequests.FindAsync(id);

                if (leaveRequest == null)
                    return NotFound();

                leaveRequest.Status = updatedLeaveRequest.Status;
                _context.LeaveRequests.Update(leaveRequest);
                await _context.SaveChangesAsync();

                return Ok(leaveRequest);
        }

            [HttpDelete("{id}")]
            [Authorize]
            public async Task<IActionResult> DeleteLeaveRequest(int id)
            {
                var leaveRequest = await _context.LeaveRequests.FindAsync(id);

                if (leaveRequest == null)
                    return NotFound();

                var employeeId = GetAuthenticatedEmployeeId();
                if (leaveRequest.EmployeeId != employeeId)
                    return Unauthorized();

                _context.LeaveRequests.Remove(leaveRequest);
                await _context.SaveChangesAsync();

                return NoContent();
            }

            private int GetAuthenticatedEmployeeId()
            {
                var employeeIdClaim = User.Claims.FirstOrDefault(c => c.Type == "EmployeeId")?.Value;
                if (int.TryParse(employeeIdClaim, out int employeeId))
                    return employeeId;

                throw new UnauthorizedAccessException("Invalid or missing Employee ID.");
        }
    }

    public class AddLeaveRequest
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public required string Reason { get; set; }
        public string Status { get; set; } = "Pending";
    }

    public class CreateLeaveRequestDto
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string Reason { get; set; }
        public string Status { get; set; }
    }

}
